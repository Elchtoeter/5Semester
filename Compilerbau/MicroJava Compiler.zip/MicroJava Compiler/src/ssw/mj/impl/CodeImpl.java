package ssw.mj.impl;

import ssw.mj.Parser;
import ssw.mj.codegen.Code;

public final class CodeImpl extends Code {

	public CodeImpl(Parser p) {
		super(p);
	}

	// TODO Exercise 5 - 6: implementation of code generation

}
