package ssw.mj.impl;

import ssw.mj.Parser;
import ssw.mj.Scanner;

public final class ParserImpl extends Parser {

	// TODO Exercise 3 - 6: implementation of parser

	public ParserImpl(Scanner scanner) {
		super(scanner);
	}

	@Override
	public void parse() {
		// TODO
	}
}
