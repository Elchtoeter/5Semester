package at.jku.cp.ai.rau.objects;

public enum Move
{
	STAY,
	SPAWN,
	UP,
	DOWN,
	LEFT,
	RIGHT
}
